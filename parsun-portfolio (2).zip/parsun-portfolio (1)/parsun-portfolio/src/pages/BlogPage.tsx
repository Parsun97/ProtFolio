import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Clock, Calendar } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScrollProgress from "@/components/ScrollProgress";

export default function BlogPage() {
  const [activeFilter, setActiveFilter] = useState("All");

  const filters = ["All", "Architecture", "Full-Stack", "Career", "Performance"];

  const allPosts = [
    { title: 'Why I Chose ASP.NET for Enterprise ERP Systems', category: 'Architecture', date: 'March 28, 2026', readTime: '5 min', excerpt: 'Exploring the performance, security, and scalability advantages of ASP.NET Core when building large-scale ERP platforms for educational institutions.' },
    { title: 'Building Real-time Features with Supabase + React', category: 'Full-Stack', date: 'March 15, 2026', readTime: '7 min', excerpt: 'How I implemented real-time chat, notifications, and live updates in RentEase using Supabase Realtime and React.' },
    { title: 'From Instructor to Full-Stack Engineer: My Journey', category: 'Career', date: 'March 5, 2026', readTime: '4 min', excerpt: 'How teaching 100+ students reshaped how I approach software engineering — from communication to debugging.' },
    { title: 'Optimizing Database Queries for High-Traffic Apps', category: 'Performance', date: 'Feb 20, 2026', readTime: '6 min', excerpt: 'Practical techniques for query optimization, indexing strategies, and caching patterns I use in production ERP systems.' },
    { title: 'Lessons from Building My First ERP from Scratch', category: 'Architecture', date: 'Jan 30, 2026', readTime: '8 min', excerpt: 'The hard-won lessons from building a full institution management system — what I got right, and what I would do differently.' },
    { title: 'Why Every Developer Should Teach', category: 'Career', date: 'Jan 10, 2026', readTime: '3 min', excerpt: 'Teaching 100 students forced me to truly understand what I thought I knew. Here is what happened when I started sharing knowledge.' },
  ];

  const filteredPosts = activeFilter === "All" 
    ? allPosts 
    : allPosts.filter(post => post.category === activeFilter);

  return (
    <main className="relative min-h-screen bg-background flex flex-col">
      <ScrollProgress />
      <Navbar />
      
      <div className="flex-1 pt-32 pb-24 container max-w-6xl mx-auto px-6">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">Blog</h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Writing about software architecture, career learnings, and the technical challenges of building at scale.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 mb-10 pb-6 border-b border-border">
          {filters.map(filter => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                activeFilter === filter 
                  ? "bg-foreground text-background" 
                  : "bg-card border border-border text-muted-foreground hover:border-primary hover:text-foreground"
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPosts.map((post, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="group flex flex-col h-full p-6 rounded-xl bg-card border border-border hover:border-primary hover:-translate-y-1 transition-all"
            >
              <div className="flex items-center gap-2 mb-4">
                <span className="px-2 py-0.5 text-xs font-bold uppercase border border-primary text-primary rounded">
                  {post.category}
                </span>
              </div>
              
              <h2 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                {post.title}
              </h2>
              
              <p className="text-sm text-muted-foreground mb-6 flex-grow leading-relaxed">
                {post.excerpt}
              </p>
              
              <div className="flex items-center justify-between pt-4 border-t border-border mt-auto">
                <div className="flex flex-col gap-1">
                  <span className="text-xs text-muted-foreground flex items-center gap-1.5"><Calendar className="w-3 h-3" /> {post.date}</span>
                  <span className="text-xs text-muted-foreground flex items-center gap-1.5"><Clock className="w-3 h-3" /> {post.readTime}</span>
                </div>
                <div className="text-sm font-bold text-primary flex items-center gap-1 group-hover:underline">
                  Read <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        {filteredPosts.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            No posts found in this category.
          </div>
        )}
      </div>

      <Footer />
    </main>
  );
}
