import { motion } from "framer-motion";
import { Download, FileText } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScrollProgress from "@/components/ScrollProgress";
import { Button } from "@/components/ui/button";

export default function EbookPage() {
  const books = [
    { 
      title: 'Get Your First Client In 30 Days', 
      category: 'Business', 
      description: 'Struggling to earn online? This practical guide shows you exactly how to get your first client, even if you are a beginner. Real strategies, real results.', 
      date: 'March 28, 2026', 
      pages: '42 pages', 
      downloadLabel: 'Download PDF',
      gradient: 'from-orange-500 to-primary'
    },
    { 
      title: 'The Power of Surrender — When Life Stands Still', 
      category: 'Spiritual', 
      description: 'A transformative journey from paralysis to liberation through the timeless principle of surrender. Drawing from the Bhagavad Gita, this book reveals how true strength comes from letting go.', 
      date: 'April 6, 2026', 
      pages: 'Long read', 
      downloadLabel: 'Download DOCX',
      gradient: 'from-purple-500 to-indigo-600'
    }
  ];

  return (
    <main className="relative min-h-screen bg-background flex flex-col">
      <ScrollProgress />
      <Navbar />
      
      <div className="flex-1 pt-32 pb-24 container max-w-6xl mx-auto px-6">
        <div className="mb-12 border-b border-border pb-8">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">Library</h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            A collection of practical guides, deep dives, and philosophical thoughts I've put together. Available for free download.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {books.map((book, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1, duration: 0.4 }}
              className="flex flex-col bg-card border border-border rounded-xl overflow-hidden hover:border-primary/50 transition-colors shadow-sm"
            >
              {/* Book Cover Area */}
              <div className={`h-56 bg-gradient-to-br ${book.gradient} p-6 flex flex-col justify-end relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/20 mix-blend-overlay"></div>
                <h2 className="relative z-10 text-2xl font-display font-bold text-white leading-tight shadow-sm">
                  {book.title}
                </h2>
              </div>
              
              <div className="p-6 flex flex-col flex-grow">
                <div className="mb-4">
                  <span className="px-2.5 py-1 text-xs font-bold uppercase border border-primary text-primary rounded-full">
                    {book.category}
                  </span>
                </div>
                
                <p className="text-sm text-muted-foreground mb-6 flex-grow leading-relaxed">
                  {book.description}
                </p>
                
                <div className="flex items-center gap-4 text-xs text-muted-foreground mb-6 font-medium">
                  <span>{book.date}</span>
                  <span className="w-1 h-1 rounded-full bg-border"></span>
                  <span className="flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" /> {book.pages}</span>
                </div>

                <Button className="w-full gap-2">
                  <Download className="w-4 h-4" />
                  {book.downloadLabel}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <Footer />
    </main>
  );
}
