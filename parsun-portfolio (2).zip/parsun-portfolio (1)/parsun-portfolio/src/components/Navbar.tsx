import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Download, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "/", isScroll: true },
    { name: "About", href: "#about", isScroll: true },
    { name: "Projects", href: "#projects", isScroll: true },
    { name: "Blog", href: "/blog", isScroll: false },
    { name: "Library", href: "/ebook", isScroll: false },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? "bg-background/90 backdrop-blur-md border-b border-border shadow-sm py-4" : "bg-transparent py-6"
      }`}
    >
      <div className="container max-w-6xl mx-auto px-6 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 group">
          <div className="w-9 h-9 rounded bg-primary flex items-center justify-center text-primary-foreground font-display font-bold text-sm transition-transform group-hover:-translate-y-0.5">
            PK
          </div>
          <span className="font-display font-bold text-lg hidden sm:block tracking-tight text-foreground">
            Parsun Kumar
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <ul className="flex items-center gap-6">
            {navLinks.map((link) => (
              <li key={link.name}>
                {link.isScroll && location === "/" ? (
                  <a
                    href={link.href === "/" ? "#hero" : link.href}
                    className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </a>
                ) : (
                  <Link
                    href={link.href.startsWith("#") ? "/" : link.href}
                    className={`text-sm font-medium transition-colors ${
                      location === link.href || (location === "/" && link.href.startsWith("#"))
                        ? "text-primary"
                        : "text-muted-foreground hover:text-primary"
                    }`}
                  >
                    {link.name}
                  </Link>
                )}
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-3">
            <Button asChild variant="outline" className="rounded-md border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all">
              <a href="#resume">
                <Download className="w-4 h-4 mr-2" />
                Resume
              </a>
            </Button>
          </div>
        </nav>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-foreground p-2 hover:text-primary transition-colors"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle Menu"
        >
          {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Nav */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-card border-b border-border shadow-lg">
          <div className="container mx-auto px-6 py-4 flex flex-col gap-2">
            {navLinks.map((link) => (
              <div key={link.name}>
                {link.isScroll && location === "/" ? (
                  <a
                    href={link.href === "/" ? "#hero" : link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="block text-base font-medium text-foreground py-3 border-b border-border"
                  >
                    {link.name}
                  </a>
                ) : (
                  <Link
                    href={link.href.startsWith("#") ? "/" : link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="block text-base font-medium text-foreground py-3 border-b border-border"
                  >
                    {link.name}
                  </Link>
                )}
              </div>
            ))}
            <div className="mt-4">
              <Button asChild className="w-full rounded-md bg-primary text-primary-foreground">
                <a href="#resume">Download Resume</a>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
