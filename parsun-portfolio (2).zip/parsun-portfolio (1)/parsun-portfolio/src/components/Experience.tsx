import { motion } from "framer-motion";

export default function Experience() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -10 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.5 } }
  };

  const experiences = [
    {
      role: "Software Engineer",
      company: "Onmouseclick",
      location: "Karnal",
      date: "Jan 2024 – Present",
      bullets: [
        "Developed & deployed full-scale ERP used by PW, KV & Gurukul institutions.",
        "Built Inventory, Billing, Student & Staff Management modules.",
        "Designed scalable ASP.NET + SQL Server architecture ensuring robust data security.",
        "Created responsive React.js UIs and optimized database queries for performance."
      ]
    },
    {
      role: "Coding Instructor & Developer",
      company: "Kalpana Chawla Institute",
      location: "Karnal",
      date: "Mar 2022 – Mar 2023",
      bullets: [
        "Trained 100+ students in full-stack web development with hands-on labs.",
        "Designed project-based curriculum focusing on real-world applications.",
        "Built demo apps and comprehensive learning documentation.",
        "Mentored students on industry-relevant projects to build their portfolios."
      ]
    }
  ];

  return (
    <section id="experience" className="py-20 border-t border-border bg-background">
      <div className="container max-w-6xl mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          <div className="mb-10">
            <h2 className="text-xs font-bold text-primary tracking-widest uppercase mb-4">Professional Journey</h2>
            <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground">Experience</h3>
          </div>

          <div className="relative pl-4 border-l border-border ml-2 flex flex-col gap-10">
            {experiences.map((exp, index) => (
              <motion.div key={index} variants={itemVariants} className="relative">
                {/* Timeline Dot */}
                <div className="absolute -left-[21px] top-1.5 w-2.5 h-2.5 bg-primary rounded-full outline outline-4 outline-background" />

                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2 mb-3">
                  <div>
                    <h4 className="text-xl font-bold text-foreground">{exp.role}</h4>
                    <p className="text-muted-foreground text-sm font-medium mt-1">
                      {exp.company} <span className="mx-1">•</span> {exp.location}
                    </p>
                  </div>
                  <div className="text-sm font-medium text-primary shrink-0 bg-primary/10 px-2.5 py-1 rounded w-fit">
                    {exp.date}
                  </div>
                </div>

                <ul className="flex flex-col gap-2 mt-4">
                  {exp.bullets.map((bullet, i) => (
                    <li key={i} className="text-muted-foreground text-sm flex items-start gap-2">
                      <span className="text-primary mt-1 text-xs">▹</span>
                      <span className="leading-relaxed">{bullet}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
