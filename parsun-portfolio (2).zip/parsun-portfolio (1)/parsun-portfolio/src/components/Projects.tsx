import { motion } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";

export default function Projects() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const projects = [
    {
      title: "Helper",
      description: "Location-based marketplace connecting users for local help, errands, and skilled services. Built with a focus on fast geospatial queries.",
      stack: ["React", "Node.js", "MongoDB", "Geolocation"],
      category: "Geo-based Platform"
    },
    {
      title: "RentEase",
      description: "Full-stack rental platform featuring dynamic booking, real-time chat, secure payments, and location-based search filtering.",
      stack: ["Next.js", "Supabase", "Stripe", "WebSocket"],
      category: "Rental Marketplace"
    },
    {
      title: "BitBuilder",
      description: "Enterprise task assignment and progress tracking tool with complex team workflows and real-time collaboration.",
      stack: ["ASP.NET", "SQL Server", "React", "MVC"],
      category: "Project Management"
    },
    {
      title: "Calcify",
      description: "Multi-calculator platform spanning finance, math, and utility domains. Built with an extensible modular architecture.",
      stack: ["React", "Tailwind", "Vite"],
      category: "Utility Platform"
    }
  ];

  return (
    <section id="projects" className="py-20 border-t border-border bg-background">
      <div className="container max-w-6xl mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h2 className="text-xs font-bold text-primary tracking-widest uppercase mb-4">Selected Works</h2>
              <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground">Featured Projects</h3>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="group bg-card border border-border rounded-xl p-6 flex flex-col h-full hover:border-primary hover:-translate-y-1 transition-all duration-300"
              >
                <div className="flex justify-between items-start mb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-primary">
                    {project.category}
                  </span>
                  <div className="flex gap-2">
                    <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="GitHub Repository">
                      <Github className="w-5 h-5" />
                    </a>
                    <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="Live Demo">
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  </div>
                </div>

                <h4 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h4>
                <p className="text-sm text-muted-foreground mb-6 flex-grow leading-relaxed">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2 pt-4 border-t border-border">
                  {project.stack.map(tech => (
                    <span key={tech} className="text-xs font-medium text-muted-foreground bg-background px-2.5 py-1 rounded border border-border">
                      {tech}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
