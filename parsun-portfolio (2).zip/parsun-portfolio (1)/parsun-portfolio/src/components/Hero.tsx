import { motion } from "framer-motion";
import { ArrowRight, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-[100dvh] flex items-center pt-24 pb-16">
      {/* Subtle grid pattern background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:3rem_3rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />

      <div className="container max-w-6xl mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-16 items-center">
        
        {/* Left Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex flex-col gap-6"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-border bg-card w-fit">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Available for hire</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-display font-bold leading-[1.1] text-foreground tracking-tight">
            Building structured, <br />
            <span className="text-primary">scalable solutions.</span>
          </h1>

          <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
            Hi, I'm <strong className="text-foreground font-medium">Parsun Kumar Patel</strong>. A full-stack engineer passionate about clean architecture, enterprise systems, and delivering user-centric digital experiences.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <Button asChild size="lg" className="rounded-md bg-primary text-primary-foreground hover:bg-primary/90 font-medium group">
              <a href="#projects">
                View My Work
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </a>
            </Button>
            <Button asChild size="lg" variant="outline" className="rounded-md border-border text-foreground hover:bg-muted font-medium">
              <a href="#contact">Get in Touch</a>
            </Button>
          </div>
        </motion.div>

        {/* Right Content - Structured Profile Card */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1, ease: "easeOut" }}
          className="relative lg:ml-auto w-full max-w-md"
        >
          <div className="bg-card border border-border rounded-xl p-6 shadow-sm flex flex-col gap-6">
            
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 rounded bg-gradient-to-br from-primary to-orange-400 flex items-center justify-center text-primary-foreground font-display font-bold text-2xl shrink-0">
                PK
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="text-xl font-display font-bold text-foreground leading-tight">Parsun K. Patel</h3>
                <p className="text-muted-foreground text-sm font-medium">Software Engineer</p>
                <div className="flex items-center gap-1.5 text-muted-foreground text-sm mt-1">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Karnal, India</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-border">
              <div className="flex flex-col">
                <span className="text-2xl font-display font-bold text-foreground">15+</span>
                <span className="text-xs text-muted-foreground font-medium mt-1">Projects</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-display font-bold text-foreground">2+</span>
                <span className="text-xs text-muted-foreground font-medium mt-1">Years</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-display font-bold text-foreground">3</span>
                <span className="text-xs text-muted-foreground font-medium mt-1">Institutions</span>
              </div>
            </div>

          </div>
        </motion.div>

      </div>
    </section>
  );
}
