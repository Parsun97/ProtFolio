import { motion } from "framer-motion";
import { BookOpen, GraduationCap } from "lucide-react";

export default function Education() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section id="education" className="py-20 border-t border-border bg-background">
      <div className="container max-w-6xl mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          <div className="mb-10">
            <h2 className="text-xs font-bold text-primary tracking-widest uppercase mb-4">Academic Background</h2>
            <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground">Education</h3>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <motion.div variants={itemVariants} className="flex gap-4 p-5 rounded-xl bg-card border border-border hover:border-muted-foreground/30 transition-colors">
              <div className="w-10 h-10 shrink-0 bg-background border border-border rounded flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="flex flex-col justify-center">
                <h4 className="text-base font-bold text-foreground">Bachelor of Computer Applications</h4>
                <p className="text-sm text-muted-foreground font-medium mt-0.5">DAV PG College, Karnal</p>
                <p className="text-xs text-muted-foreground mt-1">2022 – 2024</p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="flex gap-4 p-5 rounded-xl bg-card border border-border hover:border-muted-foreground/30 transition-colors">
              <div className="w-10 h-10 shrink-0 bg-background border border-border rounded flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="flex flex-col justify-center">
                <h4 className="text-base font-bold text-foreground">12th Standard</h4>
                <p className="text-sm text-muted-foreground font-medium mt-0.5">Kendriya Vidyalaya</p>
                <p className="text-xs text-muted-foreground mt-1">2019 – 2020</p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
