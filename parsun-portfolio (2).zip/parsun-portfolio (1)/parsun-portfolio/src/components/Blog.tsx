import { motion } from "framer-motion";
import { ArrowRight, Clock } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Blog() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const posts = [
    {
      title: "Why I Chose ASP.NET for Enterprise ERP Systems",
      category: "Architecture",
      readTime: "5 min read",
      excerpt: "Exploring the performance, security, and scalability advantages of ASP.NET Core when building large-scale ERP platforms."
    },
    {
      title: "Building Real-time Features with Supabase + React",
      category: "Full-Stack",
      readTime: "7 min read",
      excerpt: "How I implemented real-time chat, notifications, and live updates in RentEase using Supabase Realtime."
    }
  ];

  return (
    <section id="blog" className="py-20 border-t border-border bg-background">
      <div className="container max-w-6xl mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h2 className="text-xs font-bold text-primary tracking-widest uppercase mb-4">Insights & Thoughts</h2>
              <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground">Latest Articles</h3>
            </div>
            <Button asChild variant="outline" className="w-fit">
              <Link href="/blog">View all articles</Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {posts.map((post, i) => (
              <motion.div
                key={i}
                variants={itemVariants}
                className="group flex flex-col justify-between p-6 rounded-xl bg-card border border-border hover:border-primary transition-colors"
              >
                <div>
                  <div className="flex items-center gap-3 text-xs font-medium text-muted-foreground mb-4">
                    <span className="px-2 py-0.5 rounded border border-primary text-primary">{post.category}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {post.readTime}</span>
                  </div>
                  <h4 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors mb-2">
                    {post.title}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
                <div className="mt-6 flex items-center gap-1.5 text-sm font-bold text-primary group-hover:underline">
                  Read Article <ArrowRight className="w-4 h-4" />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
