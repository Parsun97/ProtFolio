import { motion } from "framer-motion";

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section id="about" className="py-20 border-t border-border bg-background">
      <div className="container max-w-6xl mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="flex flex-col gap-16"
        >
          <div className="flex flex-col md:flex-row gap-12 items-start md:items-center justify-between">
            <motion.div variants={itemVariants} className="max-w-2xl">
              <h2 className="text-xs font-bold text-primary tracking-widest uppercase mb-4">About Me</h2>
              <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground leading-tight">
                "Turning complex business challenges into elegant, scalable digital solutions."
              </h3>
            </motion.div>
            
            <motion.div variants={itemVariants} className="flex gap-6 border border-border bg-card rounded-xl p-6 shrink-0">
              <div className="flex flex-col pr-6 border-r border-border">
                <span className="text-3xl font-display font-bold text-foreground">15+</span>
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide mt-1">Projects</span>
              </div>
              <div className="flex flex-col pr-6 border-r border-border">
                <span className="text-3xl font-display font-bold text-foreground">2+</span>
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide mt-1">Years</span>
              </div>
              <div className="flex flex-col">
                <span className="text-3xl font-display font-bold text-foreground">3</span>
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide mt-1">Institutions</span>
              </div>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <motion.div variants={itemVariants} className="bg-card border border-border rounded-xl p-6 hover:-translate-y-1 transition-transform">
              <h4 className="text-lg font-display font-bold text-foreground mb-2">Clean Architecture</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Writing maintainable, robust code that scales with business needs and developer teams. Embracing best practices over shortcuts.
              </p>
            </motion.div>

            <motion.div variants={itemVariants} className="bg-card border border-border rounded-xl p-6 hover:-translate-y-1 transition-transform">
              <h4 className="text-lg font-display font-bold text-foreground mb-2">Enterprise Systems</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Building reliable, data-heavy ERPs and portals that handle complex workflows securely.
              </p>
            </motion.div>

            <motion.div variants={itemVariants} className="bg-card border border-border rounded-xl p-6 hover:-translate-y-1 transition-transform">
              <h4 className="text-lg font-display font-bold text-foreground mb-2">Modern Stack</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Bridging enterprise backends with snappy, responsive frontend experiences using the latest ecosystem tools.
              </p>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
