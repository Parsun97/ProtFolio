import { useState } from "react";
import { motion } from "framer-motion";
import { Send, Mail, MapPin, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    
    setTimeout(() => {
      setLoading(false);
      const form = e.target as HTMLFormElement;
      form.reset();
      
      toast({
        title: "Message sent",
        description: "Thanks for reaching out! I'll get back to you soon.",
      });
    }, 1000);
  };

  return (
    <section id="contact" className="py-20 border-t border-border bg-background">
      <div className="container max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
        >
          <div className="grid md:grid-cols-2 gap-16">
            <div>
              <h2 className="text-xs font-bold text-primary tracking-widest uppercase mb-4">What's Next?</h2>
              <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">Get In Touch</h3>
              <p className="text-sm text-muted-foreground mb-8 leading-relaxed max-w-md">
                Whether you have a question, a project proposal, or just want to say hi, my inbox is always open.
              </p>

              <div className="flex flex-col gap-5">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-muted-foreground" />
                  <a href="mailto:parsunkumarpatel@example.com" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
                    parsunkumarpatel@example.com
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">
                    Karnal, Haryana, India
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <Linkedin className="w-5 h-5 text-muted-foreground" />
                  <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
                    LinkedIn Profile
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <div className="space-y-1">
                  <label htmlFor="name" className="text-xs font-medium text-foreground">Name</label>
                  <Input 
                    id="name"
                    placeholder="John Doe" 
                    required 
                    className="bg-background border-border"
                  />
                </div>
                <div className="space-y-1">
                  <label htmlFor="email" className="text-xs font-medium text-foreground">Email</label>
                  <Input 
                    id="email"
                    type="email" 
                    placeholder="john@example.com" 
                    required 
                    className="bg-background border-border"
                  />
                </div>
                <div className="space-y-1">
                  <label htmlFor="message" className="text-xs font-medium text-foreground">Message</label>
                  <Textarea 
                    id="message"
                    placeholder="Hello, I'd like to talk about..." 
                    required 
                    className="bg-background border-border min-h-[120px] resize-none"
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full mt-2"
                  disabled={loading}
                >
                  {loading ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
