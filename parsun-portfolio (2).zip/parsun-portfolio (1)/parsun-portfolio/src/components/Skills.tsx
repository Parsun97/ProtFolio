import { motion } from "framer-motion";
import { SiReact, SiNextdotjs, SiNodedotjs, SiDotnet, SiMongodb, SiSupabase } from "react-icons/si";
import { Database, Code2, Layers } from "lucide-react";

export default function Skills() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const skills = [
    {
      title: "Frontend Development",
      stack: "React.js • Next.js",
      icon: <SiReact className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />,
    },
    {
      title: "Node Ecosystem",
      stack: "Node.js • Express",
      icon: <SiNodedotjs className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />,
    },
    {
      title: "Enterprise Backend",
      stack: "ASP.NET MVC • C#",
      icon: <SiDotnet className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />,
    },
    {
      title: "Database Systems",
      stack: "SQL Server • MongoDB",
      icon: <Database className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />,
    },
    {
      title: "Modern BaaS",
      stack: "Supabase • Firebase",
      icon: <SiSupabase className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />,
    },
    {
      title: "Languages",
      stack: "JavaScript • Python",
      icon: <Code2 className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />,
    }
  ];

  return (
    <section id="skills" className="py-20 border-t border-border bg-background">
      <div className="container max-w-6xl mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          <div className="mb-10">
            <h2 className="text-xs font-bold text-primary tracking-widest uppercase mb-4">Technical Arsenal</h2>
            <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground">Skills & Technologies</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {skills.map((skill, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="group flex items-start gap-4 p-5 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors"
              >
                <div className="w-10 h-10 shrink-0 bg-background border border-border rounded flex items-center justify-center">
                  {skill.icon}
                </div>
                <div>
                  <h4 className="text-base font-bold text-foreground mb-1 group-hover:text-primary transition-colors">{skill.title}</h4>
                  <p className="text-sm text-muted-foreground font-medium">{skill.stack}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <motion.div variants={itemVariants} className="mt-8 flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-muted-foreground mr-2">Additional:</span>
            {["REST APIs", "MVC Architecture", "Git", "Linux", "Power BI", "ADO.NET", "jQuery"].map(item => (
              <span key={item} className="px-3 py-1 rounded-full bg-card border border-border text-xs font-medium text-foreground hover:border-primary/50 transition-colors">
                {item}
              </span>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
